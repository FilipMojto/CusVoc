def caught_exeption(code, print: bool = False, pre_message: str = ""):

    try:
        code()
    except Exception as e:
        
        if print:
            print(f"{pre_message}" + ": " if pre_message else "" + e)




caught_exeption(code=5 / 0,

    print=True,
    pre_message="Error"
)


# from typing import Literal
# from dataclasses import dataclass
# from enum import Enum
# # Define the list of available options
# FIELDS = ['id', 'lexeme', 'definition', 'category', 'collocate', 'test_count', 'was_tested', 'for_practice']


# class EntryFilterField(Enum):
#     id = 1
#     lexeme = 2



# @dataclass
# class EntryFilter:
#     field: EntryFilterField

# # You can now access the list of fields as FIELDS
# print([field.name for field in EntryFilterField])
# EntryFilter(field=EntryFilterField.id)




## TESTING OPERATOR COMPARISON

# from typing import Literal

# def compare(val_1: object, val_2, operator: Literal['>', '>=', '<', '<=', '==', '!=']):
    
#     match operator:
#         case '>':
#             return val_1 > val_2
#         case '>=':
#             return val_1 >= val_2
#         case '<':
#             return val_1 < val_2
#         case '<=':
#             return val_1 <= val_2
#         case '==':
#             return val_1 == val_2
#         case '!=':
#             return val_1 != val_2
#         case _:
#             raise ValueError('Unknown operator provided!')
        

# print(compare(5, "sds", '<'))



## TESTING STRINGS PASSING BY REFEREMCE IN PYTHON

# a = "dskkdsk"
# b = a

# print(a)
# print(b)

# a[1] = "B"

# print(a)
# print(b)



## TESTING os name feature
# import os
# print(os.name)



## TESTING typing in Python

# def do_sth(haha: int):

#     if isinstance(haha, int):
#         print(haha)
#     else:
#         print("DSDSK")


# do_sth(haha="str")    


## TESTING python requests and 

# import requests
# import pygame
# import tempfile
# import os


# from vocabulary import Vocabulary, LexemeModel

# # Example usage
# vocabulary = Vocabulary(db_file_path='../data/vocabulary.db')
# new_lexeme = LexemeModel(string="example", example_sentence="This is an example sentence.", PAC_file_path="/path/to/file.mp3")
# new_lexeme.save()  




## TESTING peewee

# from peewee import *

# db = SqliteDatabase('people.db')

# class Person(Model):
#     name = CharField()
#     birthday = DateField()

#     class Meta:
#         database = db

    




## TESTING pygame Python Library
# import sys, os
# sys.stdout = open(os.devnull, 'w')
# import pygame
# sys.stdout = sys.__stdout__ 
# # Initialize pygame mixer
# pygame.mixer.init()

# # URL of the phonetics audio
# audio_url = "https://api.dictionaryapi.dev/media/pronunciations/en/word-us.mp3"

# Fetch the audio file from the URL
# response = requests.get(audio_url)

# with open(file='./test.mp3', mode='ab') as file:
#     file.write(response.content)



# # Ensure the request was successful
# if response.status_code == 200:
#     # Create a temporary file to save the audio
#     with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as temp_audio_file:
#         temp_audio_file.write(response.content)
#         temp_audio_file.flush()
        
#         # Save the path to the file
#         temp_audio_file_path = temp_audio_file.name

#     try:
#         # Load and play the audio file using pygame
#         pygame.mixer.music.load(temp_audio_file_path)
#         pygame.mixer.music.play()
        
#         # Keep the script running until the audio finishes playing
#         while pygame.mixer.music.get_busy():
#             continue
#     finally:
#         # Clean up the temporary file
#         os.remove(temp_audio_file_path)
# else:
#     print("Failed to retrieve the audio file.")

## TESTING passing variables to function

# i = 5


# def fun(i):
#     i -= 1

# print(i)
# fun(i)

# print(i)


## TESTING python-Levenshtein library

# import Levenshtein

# def is_similar(user_input, correct_lexeme, threshold=0.8):
#     # Compute similarity ratio
#     similarity = Levenshtein.ratio(user_input, correct_lexeme)

#     # Check if similarity is above the threshold
#     return similarity, similarity >= threshold


# print(is_similar(user_input="Presumptous", correct_lexeme="presumptuous"))






## TESTING csv library

# import csv

# # Open the CSV file
# with open('vocabulary.tsv', mode='r', encoding='utf-8') as src_file:
    
#     # Create a CSV DictReader with the correct delimiter
#     reader = csv.DictReader(src_file, delimiter=':')
    
#     # Iterate over each row in the CSV
#     for row in reader:
#         print(row)

#     # No need to explicitly close the file when using 'with' context manager    