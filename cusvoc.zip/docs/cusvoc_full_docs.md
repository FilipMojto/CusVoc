
# CusVoc Documentation

This document contains an unabridged guide on how to use CusVoc Application. All project features are also supplemented with various practical examples directly from application's interface.


## Project Abbreviations

This section contains the full collection of abbreviation used in documentation of the CusVoc project.

1. __PAC File__
    
    Pronuciation Audio Clip File

2. __TCP Algorithm__

    Testing Candidate Picker Algorithm

## Terms

At first it is important to understand several terms which are regularly used in this document


1. __Lexeme__

    - Lexeme is a more absorbing alternative for a term word which can be translated as a 'Singleword Lexeme'. Most of these lexemes have a __part-of-speech__ (noun, verb, adjective, etc.) assigned. 'Multiword Lexemes' (composite lexemes) include __phrases__, __idioms__, etc.

2. __Lexeme Category__

    - Based on the above explanation we've decided 

3. __Collocate__
4. __Lexical Entry__
    - A specific instance of a lexeme with additional context which is composed of __definition__, __lexical category__, __sentence__ and __collocate__.





## Script cusvoc.py

> For steps on how to install and run the script successfully, please refer to the section _How to install&run_ in the _README file_.



### Useful links



